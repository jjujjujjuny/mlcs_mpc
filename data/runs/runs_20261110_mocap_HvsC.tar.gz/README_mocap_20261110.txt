2026-11-10 13:52~13:58 mocap 주행 (source mocap, 1108_7_track_mocap — 실제 벽 없음, 가상 벽), recv·cmd_recv 열 있음
  135213_mocapH  H (예전, Dx×1)  v_max 1.5  랩 6.29~6.59
  135347_mocapH  H              v_max 2.0  랩 5.00~5.81
  135515_mocap   후보 (Dx×0.45) v_max 1.5  랩 6.31~6.67  (급코너 바깥 향해 출발 → 5.2 s 뒤 출발)
  135701_mocap   후보           v_max 2.0  랩 5.09~5.26  (출발 교착 → 사용자가 밀어 줌)
  wall_margin 0.28, ws_dec_max 2.5, bounds_param 켬, delay_comp 끔
