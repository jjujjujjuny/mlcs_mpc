2026-11-09 오후 라이다 MPCC 주행 (맵 1109_2, 트랙 1109_2_track, 새 H 713b031 + Cx<=1, HyperPM 끔, friction 0.41)
  커밋 37fe0ea 기준. wall_margin 0.25, wheel_speed_tau 0.4.

  drive_*_race.csv        data_logger 원본 (라이다 상태)
  drive_*_racemocap.csv   자세를 mocap 으로 바꾼 100 Hz 로그 (race_to_mocap_log)
  clean/*_clean.csv       clean_drive_log 결과 — 학습용
  align/                  map_mocap_align record (mocap + 라이다 원본)
  *_race_report.png       race_report

  주행         v_max  mocap     비고
  165859       1.0    없음      몸풀기, 랩 9.6~11 s
  170114/170216/170347 1.5  일부   출발 전/짧음 (시작 위치 안 찍어 대기 등)
  170636       1.5    있음      2바퀴 6.4~6.6 s, 위치 RMSE 5.3 cm, 벽 최소 29 cm
  170837       2.0    있음      랩 5.4~6.4 s, 위치 RMSE 9.9 cm, 수동 개입 여러 번
  171140       3.0    자율구간 없음  랩 4.2~5.2 s, 차체가 벽선 넘음 6.7% (라이다 기준). racemocap/clean 제외
  172115       2.5    없음      6바퀴 4.18~4.76 s, 벽 최소 19 cm
  173155       2.5    있음      9바퀴 정상 4.5~5.3 s, 위치 RMSE 10.2 cm, 벽 최소 18 cm.
                                중간 Cartographer 위치 13.2 cm 튐 → lidar_bridge 정지 (이후 stop_on_jump 끔)
  솔버: 전 주행 풀이 평균 24~25 ms, 솔버 고장 0
