2026-11-09 20:56~21:03 라이다 MPCC + 장애물 검출 watch (obstacles: watch — 찾기만, MPC 는 안 피함)
  v_max 2.0, wall_margin 0.28, ws_dec_max 2.5. 노드에 s 앵커 (s = s_pred + x0 − s_pred[1], 미커밋) 들어감.
  검출기 lidar_obstacles (473fd5f 판, 스캔 맞춤 없음, 코어 4 = hmpc_node 와 같은 코어였음).

  205610  맵 1109_3 (트랙이 바뀐 뒤 — 맵과 다름), mocap 있음, 검출 헛것 많음 (트랙이 바뀜)
  205807  맵 1109_4, mocap 없음, 33 s (거의 정지), 섬 끝 (1.06, 0.98) 을 내내 장애물로 봄
  205913  맵 1109_4, mocap 있음, 15바퀴 (깨끗한 랩 7.2~8.5 s)
          위치추정 RMSE 30 cm / yaw 7.7° (2 m/s 넘으면 16 cm / 3°), 맵 정렬 fit 자체 7 cm / 3.5°
          검출: 발행 59% 스캔 — 대부분 헛것 (섬·바깥 긴 벽 따라). 발행 스캔 위치 오차 중앙 33 cm vs 안 한 스캔 13 cm
          풀이 p95 49.8 ms (검출기가 같은 코어 — 지금은 코어 0~3 으로 옮김)

  파일: drive_*_race.csv, *_racemocap.csv, clean/ (학습용 2개 4.0 분), align/, *_race_report.png,
        obstacles_*.csv (lidar_obstacles 기록: 스캔마다 자세·후보·발행), obstacles_map.png (검출 위치 지도)
