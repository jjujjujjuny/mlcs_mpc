2026-11-08 저녁 VESC 제동 실험 로그 (mocap 켬, 수동 rally)

[제동 켠 직후 — 문제 있던 설정. 비교용]
  drive_20261108_183113_brake.csv  32 s
  drive_20261108_183441_brake.csv 209 s
  drive_20261108_183957_brake.csv  81 s
  VESC: s_pid_allow_braking 1, Ki 0.002, 회생 -5 A, 개루프 기본값
  증상: 저속 출발 덜덜거림(센서리스 개루프 구간), 정지 시 앞으로 튐/뒤로 굴러감

[최종 — 이 설정으로 픽스]
  drive_20261108_202008_rally.csv  63 s  (clean 58 s)
  drive_20261108_202438_rally.csv 103 s  (clean 96 s)
  VESC: 제동 켬 + 개루프 설정 수정(사용자, VESC Tool) — 저속 출발 해결
  ROS: ackermann_to_vesc 정지 처리 패치 (mlcs_mpc/patches/vesc-stop-brake.patch)
       정지 명령 & 바퀴 > 0.5 m/s → 속도 0 (VESC 강한 제동), 그 아래 → 제동 전류 10 A
  actuator_id: 감속 중앙값 -2.21 m/s² (p10 -3.51), 가속 +2.04
               MPC용 (tau 0.0461 고정) ws_acc_max 1.75, ws_dec_max 3.25, RMSE 0.175 m/s
               일정 속도 오차 +0.167 m/s
  학습 데이터: hypermpc/hpm/data/hpm_data_20261108.tar.gz (11-07 + 이 두 로그, run_id ≥ 20000)
