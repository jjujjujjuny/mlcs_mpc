venue6 (11-14 16:10~16:30) track1a, steer_plan_frac 0.85, strict. 161105 v3.2, 161502 v3.5, 161633 v4.0, 162356 v4.0 + obstacles lidar. 트랙에 다른 팀 차 많음 — 정지(S)·후진 다수는 교통일 수 있음
