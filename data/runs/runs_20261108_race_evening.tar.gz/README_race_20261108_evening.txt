2026-11-08 저녁 라이다 MPCC race (맵 1108_8, VESC 제동 켬 + 정지 처리 패치, wheel_speed_tau 0.4)

  drive_..._race.csv       data_logger (자세는 라이다)
  align/..._race.csv       mocap + 라이다 원기록 (map_mocap_align record)
  drive_..._racemocap.csv  자세를 mocap 정답으로 바꾼 100 Hz 로그 (tools/race_to_mocap_log.py)
  clean/..._racemocap_clean.csv
  *_report.png, *_eval.png  race_report

  20:48 v_max 3.0 / 20:50 3.0 / 20:55 2.2 (트랙 모양 바뀜) / 21:00 2.2 (mocap 없음 → 학습 제외)
  21:07 2.0 / 21:09 2.5 / 21:12 3.0 (wall_margin 0.25, friction 0.30) / 21:18 2.0 friction 0.27
  학습 데이터: hypermpc/hpm/data/hpm_data_20261108b.tar.gz = 20261108 + 이 레이스 5.0 분 (run_id >= 30000)
