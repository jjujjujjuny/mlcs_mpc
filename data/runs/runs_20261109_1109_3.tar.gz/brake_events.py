import sys,os,numpy as np,pandas as pd,casadi as cs
from scipy.signal import savgol_filter
sys.path.insert(0,'hypermpc'); import offline_ocp as oo
dyn,_=oo.load_naive_dynamics(os.path.expanduser('~/hypermpc_code'))
p=np.array(cs.DM(oo.scale_for_mass(oo.load_params('src/mlcs_mpc/config/hmpc.yaml')))).ravel()
def F(vx,vy,r,ws): return np.array(dyn(cs.vertcat(vx,vy,r,0.41),cs.vertcat(ws,0.0),p)).ravel()
W=0.5
for f in sys.argv[1:]:
    d=pd.read_csv(f); t=d.stamp.values; dt=0.01
    w=15
    X=savgol_filter(d.x,w,2); Y=savgol_filter(d.y,w,2); yaw=savgol_filter(np.unwrap(d.yaw.values),w,2)
    vX=np.gradient(X,t); vY=np.gradient(Y,t); r=np.gradient(yaw,t)
    vx=np.cos(yaw)*vX+np.sin(yaw)*vY; vy=-np.sin(yaw)*vX+np.cos(yaw)*vY
    ws=pd.Series(d.motor_rpm.values/4781.5).interpolate().values
    dws=np.gradient(savgol_filter(ws,w,2),t)
    n=int(W/dt); i=0; ev=[]
    while i<len(t)-n:
        if dws[i]<-3 and vx[i]>1.2 and ws[i]>1.0:
            j=slice(i,i+n)
            if np.abs(np.diff(vx[j])).max()/dt<12 and np.abs(r[j]).max()<1.5 and np.all(np.diff(t[j])<0.03):
                # 모델: vx, vy, r 적분 (조향 0 근사 대신 실제 r,vy 사용해 vx 만)
                v=vx[i]; 
                for k in range(i,i+n): v+= F(v,vy[k],r[k],ws[k])[0]*dt
                c=d.cmd_speed.values[j]; ev.append((t[i]-t[0],vx[i],ws[i:i+n].min(),vx[i+n],v,((ws[j]-vx[j])/np.maximum(vx[j],0.3)).min(),np.nanmin(c) if np.isfinite(c).any() else np.nan,np.nanmax(c) if np.isfinite(c).any() else np.nan))
            i+=n
        else: i+=1
    print(f'■ {os.path.basename(f)}  이벤트 {len(ev)}개')
    if ev:
        E=np.array(ev)
        for e in ev[:12]: print(f'   t{e[0]:6.1f}  vx {e[1]:.2f}→ 실제 {e[3]:.2f} / 모델 {e[4]:.2f}   바퀴 최저 {e[2]:.2f}  슬립 최저 {e[5]*100:.0f}%  명령 {e[6]:.2f}~{e[7]:.2f}')
        print(f'   평균 0.5 s 감속량: 실제 {np.mean(E[:,1]-E[:,3]):.2f}  모델 {np.mean(E[:,1]-E[:,4]):.2f} m/s   (모델/실제 {np.mean(E[:,1]-E[:,4])/np.mean(E[:,1]-E[:,3]):.2f})')
