2026-11-10 13:42 rally 수동 주행 (./drive.sh rally, mocap 100 Hz, 292 s) — recv·cmd_recv 열이 들어간 첫 mocap 데이터
  natnet clientIP 버그 고친 뒤 (6ca1f65 — 라이다 유선 주소로 붙던 것)
  속도: 평균 1.54 m/s, 1~2 m/s 39%, 2~3.5 m/s 32%, >3.5 m/s 2%
  회전: 오른쪽 (yaw rate < −0.5) 57% / 왼쪽 26% — 왼쪽 코너뿐이던 기존 데이터 보완용
  조향 (달릴 때): 오른쪽 큰 (< −0.3) 41% / 왼쪽 큰 20% / 중간 (0.1~0.3) 17%
  recv − stamp 중앙 3.1 ms (p95 6.2) — mocap stamp 는 natnet 이 받은 젯슨 시각이라 로거까지만
  clean 249 s (86%), segment 18
